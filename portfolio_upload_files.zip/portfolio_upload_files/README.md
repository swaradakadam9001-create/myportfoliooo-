# My Portfolio Website

A responsive portfolio website built with HTML and CSS.

## Publish using GitHub Pages
1. Upload index.html to your repository root.
2. Open Settings → Pages.
3. Choose Deploy from a branch, main, and /(root).
4. Save and wait for deployment.
